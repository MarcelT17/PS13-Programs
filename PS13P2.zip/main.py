
class Student:

  def __init__(self, code, first, last, credits):
    self.first = first
    self.last = last
    self.credits = credits
    self.code = code

  def tuition(credits):
    if code = I
      credits = 250.00
    if code = O
      credits = 500.00
    b = float(credits) * 250.00
    return b

student_1 = Student('Harry', 'Potter',25.00)

print(student_1.first)
print(student_1.last)
print(student_1.code)
print(student_1.credits(20.00))
print(student_1.credits(20.00))
